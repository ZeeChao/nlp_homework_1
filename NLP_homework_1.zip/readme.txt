第一次作业
中文词向量
目前只完成了独热、TFIDF和word2vec的实现